package com.sahil.gupte.poobgtournament;

public class Constants {

    //Tournament Details constants
    public static String nameT = "name";
    public static String TID = "TID";
    public static String cap = "cap";

    //Database Nodes
    public static String TournamentsNode = "Tournaments";
    public static String RequestsNode = "Requests";
    public static String UsersNode = "Users";
    public static String OngoingNode = "Ongoing";
    public static String ParticipantsNode = "Participants";

}
